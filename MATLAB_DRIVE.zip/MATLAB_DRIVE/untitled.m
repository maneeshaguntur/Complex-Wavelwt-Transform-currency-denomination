close all;
clear all;
n500= imread('500reall.jpg');
n500=rgb2hsv(n500);
h=n500(:,:,1);
h500=mean2(h);

n10= imread('10real.png');
n10=rgb2hsv(n10);
h=n10(:,:,1);
h10=mean2(h);

n50= imread('50real.jpg');
n50=rgb2hsv(n50);
h=n50(:,:,1);
h50=mean2(h);

n100= imread('100real.jpg');
n100=rgb2hsv(n100);
h=n100(:,:,1);
h100=mean2(h);

n200= imread('200real.jpg');
n200=rgb2hsv(n200);
h=n200(:,:,1);
h200=mean2(h);

n2000= imread('200reall.jpg');
n2000=rgb2hsv(n2000);
h=n2000(:,:,1);
h2000=mean2(h);

x=imread('100pic.jpeg');
x=rgb2hsv(x);
h=x(:,:,1);
hx=mean2(h);

d10=abs(hx-h10);
d50=abs(hx-h50);
d100=abs(hx-h100);
d200=abs(hx-h200);
d500=abs(hx-h500);
d2000=abs(hx-h200);

a=[d10,d50,d100,d200,d500,d2000];
if min(a)==d10
    disp("10");

elseif min(a)==d50
    disp("50");
    
elseif min(a)==d100
    disp("100");
 
elseif min(a)==d200
    disp("200");

 elseif min(a)==d500
    disp("500");

else 
    disp("2000");
   end
    












