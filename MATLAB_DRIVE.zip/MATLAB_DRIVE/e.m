close all;
clear all;
x= imread('500real.jpg');
x = rgb2gray(x);
%x=imbinarize(x)
x=medfilt2(x);
figure(1)
imshow(x)
%[LoD,HiD] = wfilters('haar','d');
figure(2)
%[cA,cH,cV,cD] = dwt2(x,LoD,HiD,'mode','symh');
[a,d] = dualtree2(x,'Level',2);
%subplot(2,2,1)
% imagesc(cA)
% colormap gray
% title('Approximation')
% subplot(2,2,2)
% imagesc(cH)
% colormap gray
% title('Horizontal')
% subplot(2,2,3)
% imagesc(cV)
% colormap gray
% title('Vertical')
% subplot(2,2,4)
% imagesc(cD)
% colormap gray
% title('Diagonal')
orientation = ["HL","HH","LH","LH","HH","HL"];
for k=1:6
    subplot(3,2,k)
    imagesc(imag(d{1}(:,:,k)))
    title(['Orientation:' orientation(k)])
    set(gca,'xtick',[])
    set(gca,'ytick',[])
end
colormap gray
%set(gcf,'Position',[0 0 560 800])
m=mean2(d{2}(:,:,1))



