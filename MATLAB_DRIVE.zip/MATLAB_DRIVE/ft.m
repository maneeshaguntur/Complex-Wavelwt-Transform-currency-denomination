close all;
clear all;
outputfolder=fullfile('training/');
cat={'10','20','50','100','200','500','2000'};%different folders in the training folder
imds=imageDatastore(fullfile(outputfolder,cat),'LabelSource','foldernames');

tbl = countEachLabel(imds);%count of no. of images in each folder
minSetCount = min(tbl{:,2})%for ease of using loop; minsetcount=100 since least amount of images in a category is 100

imds = splitEachLabel(imds, minSetCount, 'randomize');%choosing 100 images from each category
countEachLabel(imds)

n10 = find(imds.Labels == '10', 1);%first instance of the image of the respecti
% ve category
n20 = find(imds.Labels == '20', 1);
n50 = find(imds.Labels == '50', 1);
n100 = find(imds.Labels == '100', 1);
n200 = find(imds.Labels == '200', 1);
n500 = find(imds.Labels == '500', 1);
n2000 = find(imds.Labels == '2000', 1);

for i=1:700 %total 700 images in training dataet since 100 of each category
    img=readimage(imds,i);
    img=rgb2gray(img);
[a,d]=dualtree2(img,'Level',2);%first level dwt
%[LL2, LH2, HL2 ,HH2] = dwt2(LL, 'haar');%seconf level dwt
features(i,:)=[mean2(d{2}(:,:,1)),mean2(d{2}(:,:,2)),mean2(d{2}(:,:,3)),mean2(d{2}(:,:,4)),mean2(d{2}(:,:,5)),mean2(d{2}(:,:,6)),...
    mean2(d{1}(:,:,1)),mean2(d{1}(:,:,2)),mean2(d{1}(:,:,3)),mean2(d{1}(:,:,4)),mean2(d{1}(:,:,5)),mean2(d{1}(:,:,6)),...
    std2(d{2}(:,:,1)),std2(d{2}(:,:,2)),std2(d{2}(:,:,3)),std2(d{2}(:,:,4)),std2(d{2}(:,:,5)),std2(d{2}(:,:,6)),...
    std2(d{1}(:,:,1)),std2(d{1}(:,:,2)),std2(d{1}(:,:,3)),std2(d{1}(:,:,4)),std2(d{1}(:,:,5)),std2(d{1}(:,:,6)),...
    skewness(d{2}(:,:,1),1,'all'),skewness(d{2}(:,:,2),1,'all'),skewness(d{2}(:,:,3),1,'all'),skewness(d{2}(:,:,4),1,'all'),skewness(d{2}(:,:,5),1,'all'),skewness(d{2}(:,:,6),1,'all'),...
    skewness(d{1}(:,:,1),1,'all'),skewness(d{1}(:,:,2),1,'all'),skewness(d{1}(:,:,3),1,'all'),skewness(d{1}(:,:,4),1,'all'),skewness(d{1}(:,:,5),1,'all'),skewness(d{1}(:,:,6),1,'all'),...
    kurtosis(d{2}(:,:,1),1,'all'),kurtosis(d{2}(:,:,2),1,'all'),kurtosis(d{2}(:,:,3),1,'all'),kurtosis(d{2}(:,:,4),1,'all'),kurtosis(d{2}(:,:,5),1,'all'),kurtosis(d{2}(:,:,6),1,'all'),...
    kurtosis(d{1}(:,:,1),1,'all'),kurtosis(d{1}(:,:,2),1,'all'),kurtosis(d{1}(:,:,3),1,'all'),kurtosis(d{1}(:,:,4),1,'all'),kurtosis(d{1}(:,:,5),1,'all'),kurtosis(d{1}(:,:,6),1,'all')];
   %feature vector is 700x28 matrix.calculated features using mean,standard
   %deviation, kurtosis and skewness using the dwt coefficients
    
end

% %matrix for response variable. f is 700x1
for i=1:700
    if(i<=100)
        f(i,1)={'10'};
    elseif(i>100&&i<=200)
        f(i,1)={'20'}'
     elseif(i>200&&i<=300)
        f(i,1)={'50'}
         elseif(i>300&&i<=400)
        f(i,1)={'100'};
         elseif(i>400&&i<=500)
        f(i,1)={'200'}
         elseif(i>500&&i<=600)
        f(i,1)={'500'}
    else
        f(i,1)={'2000'}
        
    end
     
end

%dist = @(a,b)sqrt(bsxfun(@plus,((real(a)-real(b)).^2),((imag(a)-imag(b)).^2)));
%dist = @(a,b)sqrt(((real(a)-real(b)).^2)+((imag(a)-imag(b)).^2));

%@(a,b)dist(a,b)
% %classificationKNN = fitcknn(features,f,'NumNeighbors',35)
%classificationKNN =fitcknn(features,f,'Distance', @(a,b)dist(a,b), 'NumNeighbors',35,'Standardize',1);
%knn function using k=35 and first two paremeters are predictor variable matrix and response variable matrix
%similarly for testing i calculated the feature vectors for the validation dataset and used
%label=predict(ClassificationKNN,features)
classificationKNN = fitcknn(...
    features, ...
    f, ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 35, ...
    'DistanceWeight', 'SquaredInverse', ...
    'Standardize', true, ...
    'ClassNames', {'10'; '100'; '20'; '200'; '2000'; '50'; '500'});


