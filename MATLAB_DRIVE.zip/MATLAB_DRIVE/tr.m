outputfolder=fullfile('training/');
cat={'10','20','50','100','200','500','2000'};
imds=imageDatastore(fullfile(outputfolder,cat),'LabelSource','foldernames');

tbl = countEachLabel(imds);
minSetCount = min(tbl{:,2})

imds = splitEachLabel(imds, minSetCount, 'randomize');
countEachLabel(imds)

n10 = find(imds.Labels == '10', 1);
n20 = find(imds.Labels == '20', 1);
n50 = find(imds.Labels == '50', 1);
n100 = find(imds.Labels == '100', 1);
n200 = find(imds.Labels == '200', 1);
n500 = find(imds.Labels == '500', 1);
n2000 = find(imds.Labels == '2000', 1);

% figure(1)
% subplot(3,1,1);
% imshow(readimage(imds,n10));
% subplot(3,1,2);
% imshow(readimage(imds,n20));
% subplot(3,1,3);
% imshow(readimage(imds,n50));
% figure(2)
% subplot(2,2,1);
% imshow(readimage(imds,n100));
% subplot(2,2,2);
% imshow(readimage(imds,n200));
% subplot(2,2,3);
% imshow(readimage(imds,n500));
% subplot(2,2,4);
% imshow(readimage(imds,n2000));

net=resnet50();
% figure(3)
% plot(net)
% title('First section of ResNet-50')
% set(gca,'YLim',[150 170]);

net.Layers(1)
net.Layers(end)

numel(net.Layers(end).ClassNames)
[trainingSet, testSet] = splitEachLabel(imds, 0.3, 'randomize');
imageSize = net.Layers(1).InputSize;
augmentedTrainingSet = augmentedImageDatastore(imageSize, trainingSet, 'ColorPreprocessing', 'gray2rgb');
augmentedTestSet = augmentedImageDatastore(imageSize, testSet, 'ColorPreprocessing', 'gray2rgb');

w1 = net.Layers(2).Weights;
w1 = mat2gray(w1);
w1 = imresize(w1,5); 

 figure(4)
 montage(w1)
 title('First convolutional layer weights')

featureLayer = 'fc1000';
trainingFeatures = activations(net, augmentedTrainingSet, featureLayer,'MiniBatchSize', 32, 'OutputAs', 'columns');

trainingLabels = trainingSet.Labels;
classifier = fitcecoc(trainingFeatures, trainingLabels, ...
    'Learners', 'Linear', 'Coding', 'onevsall', 'ObservationsIn', 'columns');

testFeatures = activations(net, augmentedTestSet, featureLayer, ...
    'MiniBatchSize', 32, 'OutputAs', 'columns');

predictedLabels = predict(classifier, testFeatures, 'ObservationsIn', 'columns');
testLabels = testSet.Labels;
confMat = confusionmat(testLabels, predictedLabels);
confMat = bsxfun(@rdivide,confMat,sum(confMat,2));
a=mean(diag(confMat));

testImage = imread("50w.jpg");
%testLabel = testSet.Labels(2)

ds = augmentedImageDatastore(imageSize, testImage, 'ColorPreprocessing', 'gray2rgb');
imageFeatures = activations(net, ds, featureLayer, 'OutputAs', 'columns');
predictedLabel = predict(classifier, imageFeatures, 'ObservationsIn', 'columns');

disp(predictedLabel);


