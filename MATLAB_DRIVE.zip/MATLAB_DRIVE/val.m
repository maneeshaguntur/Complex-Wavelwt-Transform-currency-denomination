close all;
clear all;
outputfolder=fullfile('validation/');
cat={'10','20','50','100','200','500','2000'};
imds=imageDatastore(fullfile(outputfolder,cat),'LabelSource','foldernames');

tbl = countEachLabel(imds);
minSetCount = min(tbl{:,2})

imds = splitEachLabel(imds, minSetCount, 'randomize');
countEachLabel(imds)

n10 = find(imds.Labels == '10', 1);
n20 = find(imds.Labels == '20', 1);
n50 = find(imds.Labels == '50', 1);
n100 = find(imds.Labels == '100', 1);
n200 = find(imds.Labels == '200', 1);
n500 = find(imds.Labels == '500', 1);
n2000 = find(imds.Labels == '2000', 1);

for i=1:23
    img=readimage(imds,i);
    img=rgb2gray(img)
[LL,LH,HL,HH]=dwt2(img,'haar');
[LL2, LH2, HL2 ,HH2] = dwt2(LL, 'haar');
[LL3, LH3, HL3, HH3] = dwt2(LL2, 'haar');
features(i,:)=[mean2(LH),mean2(HH3),mean2(HL),mean2(HH),mean2(LL2),mean2(LH2),mean2(HL2),mean2(HH2),mean2(LH3),mean2(HL3)...
    mean2(var(LH)),mean2(var(HH3)),mean2(var(HL)),mean2(var(HH)),mean2(var(LL2)),mean2(var(LH2)),mean2(var(HL2)),mean2(var(HH2)),mean2(var(LH3)),mean2(var(HL3))];
    
    
end


