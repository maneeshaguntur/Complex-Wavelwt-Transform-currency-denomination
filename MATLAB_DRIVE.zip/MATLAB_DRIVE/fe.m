close all;
clear all;
outputfolder=fullfile('validation/');
cat={'10','20','50','100','200','500','2000'};
imds=imageDatastore(fullfile(outputfolder,cat),'LabelSource','foldernames');

tbl = countEachLabel(imds);
minSetCount = min(tbl{:,2})

imds = splitEachLabel(imds, minSetCount, 'randomize');
countEachLabel(imds)

n10 = find(imds.Labels == '10', 1);
n20 = find(imds.Labels == '20', 1);
n50 = find(imds.Labels == '50', 1);
n100 = find(imds.Labels == '100', 1);
n200 = find(imds.Labels == '200', 1);
n500 = find(imds.Labels == '500', 1);
n2000 = find(imds.Labels == '2000', 1);

for i=1:23
    img=readimage(imds,i);
    img=rgb2gray(img)
[LL,LH,HL,HH]=dwt2(img,'haar');
[LL2, LH2, HL2 ,HH2] = dwt2(LL, 'haar');
%[LL3, LH3, HL3, HH3] = dwt2(LL2, 'haar');
features(i,:)=[mean2(LH),mean2(HL),mean2(HH),mean2(LL2),mean2(LH2),mean2(HL2),mean2(HH2),...
    std2(LH),std2(HL),std2(HH),std2(LL2),std2(LH2),std2(HL2),std2(HH2),...
    skewness(LH,1,'all'),skewness(HL,1,'all'),skewness(HH,1,'all'),skewness(LL2,1,'all'),skewness(LH2,1,'all'),skewness(HL2,1,'all'),skewness(HH2,1,'all')...
    kurtosis(LH,1,'all'),kurtosis(HL,1,'all'),kurtosis(HH,1,'all'),kurtosis(LL2,1,'all'),kurtosis(LH2,1,'all'),kurtosis(HL2,1,'all'),kurtosis(HH2,1,'all')];
    
end
for i=1:700
    if(i<=100)
        f(i,1)={'10'};
    elseif(i>100&&i<=200)
        f(i,1)={'20'}'
     elseif(i>200&&i<=300)
        f(i,1)={'50'}
         elseif(i>300&&i<=400)
        f(i,1)={'100'};
         elseif(i>400&&i<=500)
        f(i,1)={'200'}
         elseif(i>500&&i<=600)
        f(i,1)={'500'}
    else
        f(i,1)={'2000'}
        
    end
    
end

%classificationKNN = fitcknn(features,f,'NumNeighbors',35)
classificationKNN = fitcknn(...
    features, ...
    f, ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 10, ...
    'DistanceWeight', 'SquaredInverse', ...
    'Standardize', true);
