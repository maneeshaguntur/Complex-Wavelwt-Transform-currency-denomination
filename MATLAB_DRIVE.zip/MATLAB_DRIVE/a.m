close all;
clear all;
imds = imageDatastore('training/','IncludeSubfolders',true,'LabelSource','foldernames');
tbl = countEachLabel(imds);
[trainingSet, validationSet] = splitEachLabel(imds, 0.6, 'randomize');
extractorFcn = @Extractor;
bag = bagOfFeatures(imds,'CustomExtractor',extractorFcn);
img = readimage(imds, 1);
featureVector = encode(bag, img);

categoryClassifier = trainImageCategoryClassifier(trainingSet, bag);
confMatrix = evaluate(categoryClassifier, trainingSet);
confMatrix = evaluate(categoryClassifier, validationSet);
