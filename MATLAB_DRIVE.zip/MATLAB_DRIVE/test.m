close all;
clear all;
img=imread("50w.jpg");
    img=rgb2gray(img);
[LL,LH,HL,HH]=dwt2(img,'haar');
[LL2, LH2, HL2 ,HH2] = dwt2(LL, 'haar');
%[LL3, LH3, HL3, HH3] = dwt2(LL2, 'haar');
features={mean2(LH),mean2(HL),mean2(HH),mean2(LL2),mean2(LH2),mean2(HL2),mean2(HH2),...
    std2(LH),std2(HL),std2(HH),std2(LL2),std2(LH2),std2(HL2),std2(HH2),...
    skewness(LH,1,'all'),skewness(HL,1,'all'),skewness(HH,1,'all'),skewness(LL2,1,'all'),skewness(LH2,1,'all'),skewness(HL2,1,'all'),skewness(HH2,1,'all')...
    kurtosis(LH,1,'all'),kurtosis(HL,1,'all'),kurtosis(HH,1,'all'),kurtosis(LL2,1,'all'),kurtosis(LH2,1,'all'),kurtosis(HL2,1,'all'),kurtosis(HH2,1,'all')};
 predictorNames = {'lhm', 'hlm', 'hhm', 'll2m', 'lh2m', 'hl2m', 'hh2m', 'lhsd', 'hlsd', 'hhsd', 'll2sd', 'lh2sd', 'hl2sd', 'hh2sd', 'lhs', 'hls', 'hhs', 'll2s', 'lh2s', 'hl2s', 'hh2s', 'lhk', 'hlk', 'hhk', 'll2k', 'lh2k', 'hl2k', 'hh2k'};
%ft=array2table(features,'VariableNames',predictorNames);
