close all;
clear all;
outputfolder=fullfile('validation/');
cat={'10','20','50','100','200','500','2000'};%different folders in the training folder
imds=imageDatastore(fullfile(outputfolder,cat),'LabelSource','foldernames');

tbl = countEachLabel(imds);%count of no. of images in each folder
minSetCount = min(tbl{:,2})%for ease of using loop; minsetcount=100 since least amount of images in a category is 100

imds = splitEachLabel(imds, minSetCount, 'randomize');%choosing 100 images from each category
countEachLabel(imds)

n10 = find(imds.Labels == '10', 1);%first instance of the image of the respective category
n20 = find(imds.Labels == '20', 1);
n50 = find(imds.Labels == '50', 1);
n100 = find(imds.Labels == '100', 1);
n200 = find(imds.Labels == '200', 1);
n500 = find(imds.Labels == '500', 1);
n2000 = find(imds.Labels == '2000', 1);

for i=1:23 %total 700 images in training dataet since 100 of each category
    img=readimage(imds,i);
    img=rgb2gray(img);
[LL,LH,HL,HH]=dwt2(img,'haar');%first level dwt
[LL2, LH2, HL2 ,HH2] = dwt2(LL, 'haar');%seconf level dwt
features(i,:)=[mean2(LH),mean2(HL),mean2(HH),mean2(LL2),mean2(LH2),mean2(HL2),mean2(HH2),...
    std2(LH),std2(HL),std2(HH),std2(LL2),std2(LH2),std2(HL2),std2(HH2),...
    skewness(LH,1,'all'),skewness(HL,1,'all'),skewness(HH,1,'all'),skewness(LL2,1,'all'),skewness(LH2,1,'all'),skewness(HL2,1,'all'),skewness(HH2,1,'all')...
    kurtosis(LH,1,'all'),kurtosis(HL,1,'all'),kurtosis(HH,1,'all'),kurtosis(LL2,1,'all'),kurtosis(LH2,1,'all'),kurtosis(HL2,1,'all'),kurtosis(HH2,1,'all')];
   %feature vector is 700x28 matrix.calculated features using mean,standard
   %deviation, kurtosis and skewness using the dwt coefficients
    
end

%matrix for response variable. f is 700x1
%%knn function using k=35 and first two paremeters are predictor variable matrix and response variable matrix
%similarly for testing i calculated the feature vectors for the validation dataset and used
%label=predict(classification,featuresvalidationdata)